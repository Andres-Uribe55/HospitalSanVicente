﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HospitalSanVicente.Migrations
{
    /// <inheritdoc />
    public partial class FixToAppointment : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
