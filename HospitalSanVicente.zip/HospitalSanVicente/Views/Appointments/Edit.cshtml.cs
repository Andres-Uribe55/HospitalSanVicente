using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HospitalSanVicente.Views.Appointments;

public class Edit : PageModel
{
    public void OnGet()
    {
        
    }
}