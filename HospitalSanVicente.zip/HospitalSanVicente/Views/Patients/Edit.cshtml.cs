using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HospitalSanVicente.Views.Patients;

public class Edit : PageModel
{
    public void OnGet()
    {
        
    }
}