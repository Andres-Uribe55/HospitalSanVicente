using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HospitalSanVicente.Views.Patients;

public class Index : PageModel
{
    public void OnGet()
    {
        
    }
}