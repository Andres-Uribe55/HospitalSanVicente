using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HospitalSanVicente.Views.Patients;

public class Create : PageModel
{
    public void OnGet()
    {
        
    }
}