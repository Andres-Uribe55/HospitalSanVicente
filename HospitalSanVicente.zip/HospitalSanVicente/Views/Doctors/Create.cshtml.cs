using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HospitalSanVicente.Views.Doctors;

public class Create : PageModel
{
    public void OnGet()
    {
        
    }
}