using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HospitalSanVicente.Views.Doctors;

public class Index : PageModel
{
    public void OnGet()
    {
        
    }
}